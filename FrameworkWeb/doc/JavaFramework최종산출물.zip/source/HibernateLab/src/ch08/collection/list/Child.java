package ch08.collection.list;

public class Child {
	
	private String name;
	private Parent p;
	
	public Child(String name){
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Parent getP() {
		return p;
	}
	public void setP(Parent p) {
		this.p = p;
	}
	
	

}
