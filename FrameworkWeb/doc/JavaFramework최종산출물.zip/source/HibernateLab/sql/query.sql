


select * from tb_member;

select * from parent;

select * from child;


select * from tb_parent;

select * from tb_child;


