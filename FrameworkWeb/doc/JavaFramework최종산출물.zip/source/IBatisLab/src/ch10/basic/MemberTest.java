package ch10.basic;

import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class MemberTest {

	private static SqlMapClient sqlMapClient;

	public static SqlMapClient getSqlMapClient() throws Exception {
		Reader reader = Resources.getResourceAsReader("sql-map-config.xml");
		SqlMapClient sqlMap = SqlMapClientBuilder.buildSqlMapClient(reader);
		return sqlMap;
	}
	
	public void printList(List list){
		for(int i=0; i<list.size(); i++){
//			Map data = (Map)list.get(i);
//			System.out.println(data.get("NAME"));
			System.out.println(list.get(i));
		}
	}
	
	public void memberList() throws Exception{
		List list = sqlMapClient.queryForList("getMemberList");
		printList(list);
	}
	
	// parameterClass ��� ��
	public void test01() throws Exception{
		Member member = new Member();
		member.setDeptNo(1);
		member.setName("ȫ�浿");
		member.setAddr("Busan");
		sqlMapClient.insert("Basic.insertMember", member);
		
		memberList();
	}

	// parameterMap ��� ��
	public void test02() throws Exception{
		Member member = new Member();
		member.setDeptNo(1);
		member.setName("�Ӳ���");
		member.setAddr("Incheon");
		sqlMapClient.insert("Basic.insertMemberByMap", member);
		
		memberList();
	}
	
	// parameterClass�� Map�� ���
	public void test03() throws Exception{
		Map map = new HashMap();
		map.put("deptNo", 2);
		map.put("name", "�̼���");
		map.put("addr", "Suwon");
		
		sqlMapClient.insert("Basic.insertMember", map);
		
		memberList();
	}
	
//	 parameterClass�� Map�� ���
	public void test04() throws Exception{	
		Member member = (Member)sqlMapClient.queryForObject("Basic.getMemberListResultMap", new Integer(1));
		
		System.out.println(member);
	}
	
	public void test05() throws Exception{
		Map map = new HashMap();
		map.put("addrs", new String[]{"Seoul", "Busan"});
		List list = sqlMapClient.queryForList("Basic.getMemberListArray", map);
		printList(list);
	}
	
	public static void main(String[] args) throws Exception{
		MemberTest test = new MemberTest();
		sqlMapClient = getSqlMapClient();
		
//		test.memberList();
		
//		test.test01();
//		test.test02();
//		test.test03();
//		test.test04();
		test.test05();
		
	}
}













