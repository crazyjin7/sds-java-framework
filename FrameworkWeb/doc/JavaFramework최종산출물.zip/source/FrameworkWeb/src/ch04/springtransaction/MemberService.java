package ch04.springtransaction;

public interface MemberService {
	
	public void registMember(Member member);
}
