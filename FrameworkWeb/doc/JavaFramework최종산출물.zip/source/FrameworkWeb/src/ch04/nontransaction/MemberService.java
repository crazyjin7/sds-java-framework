package ch04.nontransaction;

public interface MemberService {
	
	public void registMember(Member member);
}
