package ch04.springtransaction2;

public interface MemberService {
	
	public void registMember(Member member);
}
