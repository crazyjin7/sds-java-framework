package ch02.dice2;

public interface Dice {
	public int getDiceValue();
}
