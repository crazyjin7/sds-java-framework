package ch02.dice;

public interface Dice {
	public int getDiceValue();
}
