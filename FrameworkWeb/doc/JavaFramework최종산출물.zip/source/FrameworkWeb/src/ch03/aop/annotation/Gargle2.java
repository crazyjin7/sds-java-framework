package ch03.aop.annotation;


public class Gargle2 {
	

	public void doGargle() throws Throwable{
		System.out.println(" ---> �� ��ġ�Ѵ�.");
	}

}






















