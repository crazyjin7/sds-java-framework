package ch03.aop.advice;

public interface Dice {
	public int getDiceValue();
	
}
