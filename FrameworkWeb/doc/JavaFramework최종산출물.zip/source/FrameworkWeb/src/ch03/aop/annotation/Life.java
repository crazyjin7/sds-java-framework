package ch03.aop.annotation;

public interface Life {
	
	public void eatBreakfast();
	public void eatLunch();
	public void eatDinner();
	public void gotoWork();
	public void comebackHome();
	public void date();

}











