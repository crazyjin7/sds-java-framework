package ch03.proxy;

public interface EmpManager {
	
	public String getGreetingMessage(String message) throws Exception;

}
